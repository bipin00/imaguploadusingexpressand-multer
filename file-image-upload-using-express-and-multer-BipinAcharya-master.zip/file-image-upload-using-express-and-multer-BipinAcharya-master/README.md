<h1>Image upload process into folder using multer library</h1>

<strong>Multer Assignment</strong>
1. Created project folder.
2. Installed EJS (Embedded JavaScript templates)
3. Installed Express Framework.
4. Installed Multer library for file handling.
5. Resources folder are separated using CSS, JS, FONTAWESOME.
6. EJS file are in view folder.
7. AJAX and JQuery are used in the project.
